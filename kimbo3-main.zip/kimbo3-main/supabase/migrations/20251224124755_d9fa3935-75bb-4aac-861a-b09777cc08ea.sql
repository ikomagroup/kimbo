-- Ajouter "main_oeuvre" au type besoin_type_enum
ALTER TYPE besoin_type_enum ADD VALUE IF NOT EXISTS 'main_oeuvre';